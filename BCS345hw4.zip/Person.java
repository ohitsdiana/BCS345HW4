public class Person 
{
    // Private Instance Fields
    private String firstName;
    private String lastName;
    
    // No-Arg Constructor
    public Person()
    {
        firstName = "No";
        lastName = " Name";
    }
    
    // Overloaded Constructor
    public Person(String firstName, String lastName)
    {
        this.firstName = firstName;
        this.lastName = lastName;
    }
    
    // Copy Constructor
    public Person(Person person)
    {
        this.firstName = person.firstName;
        this.lastName = person.lastName;
    }
    
    // getFirstName
    public String getFirstName()
    {
        return firstName;
    }
    
    // getLastName
    public String getLastName()
    {
        return lastName;
    }
    
    // setFirstName
    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }
    
    // setLastName
    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }
    
    // toString
    public String toString()
    {
        return(firstName + " " + lastName);
    }
    
    // equals
    public boolean equals(Person person)
    {
        if(firstName.equals(person.firstName) && lastName.equals(person.lastName))
        {
            return true;
        }
        else
        {
            return false;
        }
    }   
    
    // system.out.println(" I certify that this submission is my own original work: Diana Guerrero R01901747");
}
