public class Date 
{
    // Private Instance Fields
    private int day;
    private int year;
    private int month;

    // No-Arg Constructor
    public Date()
    {
        day = 1;
        month = 1;
        year = 2001;
    }
    
    // Overloaded Constructor
    public Date(int day, int month, int year)
    {
        setDate(day, year, month);
    }
    
    // Copy Constructor
    public Date(Date other)
    {
        this.day = other.day;
        this.year = other.year;
        this.month = other.month;
    }
    
    // getDay
    public int getDay()
    {
        return day;
    }
    
    // getYear
    public int getYear()
    {
        return year;
    }
    
    // getMonth
    public int getMonth()
    {
        return month;
    }
    
    // setDate
    public void setDate(int day, int year, int month)
    {
        // Part 1
        if(year >= 1900 && year <= 2019)
            this.year = year;
        else
            this.year = 2001;
        
        // Part 2
        if(month >= 1 && month <= 12)
            this.month = month;
        else
            this.month = 1;
        
        // Part 3
        if(this.month == 1 || this.month == 3 || this.month == 5 || this.month == 7 || this.month == 8 || this.month == 10 || this.month == 12)
        {
            if(day >= 1 && day <= 31)
                this.day = day;
            else
                this.day = 1;
        }
        
        else if(this.month == 4 || this.month == 6 || this.month == 9 || this.month == 11)
        {
            if(day >= 1 && day <= 30)
                this.day = day;
            else
                this.day = 1;
        }
        
        else if(this.month == 2)
        {
            if(day >= 1 && day <= 28)
                this.day = day;
            else
                this.day = 1;
        }
    }
    
    // toString format YYYY-MM-DD
    public String toString()
    {
        return(year + "-" + String.format("%02d", month) + "-" + String.format("%02d", day));
    }
    
    // equals
    public boolean equals(Date date)
    {
        return((day == date.day) && (year == date.year) && (month == date.month));
    }
    
    // system.out.println(" I certify that this submission is my own original work: Diana Guerrero R01901747");
}
