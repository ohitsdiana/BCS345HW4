public class Employee extends Person
{
    // Private Instance Fields
    private int ID;
    private Date hireDate;
    
    // No-Arg Constructor
    public Employee()
    {
        super();
        ID = 0;
        hireDate = new Date();
    }
    
    // Overloaded Constructor
    public Employee(String firstName, String lastName, int ID, int day, int year, int month)
    {
        super(firstName, lastName);
        setID(ID);
        hireDate = new Date(year, month, day);
    }
    
    // Copy Constructor
    public Employee(Employee other)
    {
        super(other);
        setID(other.ID);
        hireDate = new Date(other.hireDate);
    }
    
    // getID
    public int getID()
    {
        return ID;
    }
    
    // getHireDate
    public Date getHireDate()
    {
        return hireDate;
    }
    
    // setID
    public void setID(int ID)
    {
        if(ID < 0)
            this.ID = 0;
        else
            this.ID = ID;
    }
    
    // setHireDate
    public void setHireDate(Date hireDate)
    {
        this.hireDate = hireDate;
    }
    
    // toString
    public String toString()
    {
        return(super.toString() + " " + ID + " " + hireDate.toString());
    }
    
    // equals
    public boolean equals(Employee other)
    {
        return((super.equals(other)) && (ID == other.ID) && (hireDate.equals(other.hireDate)));
    }
    
    // system.out.println(" I certify that this submission is my own original work: Diana Guerrero R01901747");
}
