import java.io.File;
import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class BCS345hw4 
{  
    public static void main(String[] args) throws FileNotFoundException
    { 
        // Task 1 
        // Testing Date Class
        Date dateone = new Date(1999, 8, 21);
        System.out.println(dateone.toString());
        Date datetwo = new Date(dateone);
        System.out.println(datetwo.toString());
        System.out.println(" ");
        
        // Testing Person Class
        Person person = new Person();
        System.out.println(person.toString());
        Person personone = new Person("Diana", "Guerrero");
        System.out.println(personone.toString());
        Person persontwo = new Person(personone);
        System.out.println(persontwo.equals(personone));
        System.out.println(" ");
        
        // Testing Employee Class
        Employee employeeone = new Employee();
        System.out.println(employeeone.toString());
        Employee employeetwo = new Employee("Diana", "Guerrero", 21081, 1999, 8, 21);
        System.out.println(employeetwo.toString());
        Employee employeethree = new Employee(employeetwo);
        System.out.println(employeethree.toString());
        System.out.println(employeethree.equals(employeeone));
        
        // Task 3 & 5
        Employee employees[] = new Employee[50];
        int index = 0;
        int ID, day, year, month;
        String firstName, lastName;
        
        try
        {
            File file = new File("hw4data.txt");
            Scanner infile = new Scanner(file);
            
            while(infile.hasNextLine())
            {
                ID = infile.nextInt();
                firstName = infile.next();
                lastName = infile.next();
                year = infile.nextInt();
                month = infile.nextInt();
                day = infile.nextInt();
                
                employees[index] = new Employee(firstName, lastName, ID, year, month, day);
                index++;
            }
            
            infile.close();
            
          System.out.println("Employees: ");
            
            for (int i = 0; i < index; i++)
            {
                System.out.println(employees[i].toString());
            }
            
            processHireYear(employees, index);
        }
        
        catch (FileNotFoundException e)
        {
            System.out.println("File not found.");
        }
        
        catch (InputMismatchException e)
        {
            System.out.println("Info entered error.");
        }
        
        catch (NullPointerException e)
        {
            System.out.println("Null pointer.");
        }      
}
    
    // Task 4
    public static void displayEmployees(Employee employees[], int numEmployees)
    {
        for(int i = 0; i < numEmployees; i++)
        {
            System.out.println(employees[i]);
        }
    } 
    
    // Task 6
    public static void processHireYear(Employee employees[], int numEmployees)
    {
        if(numEmployees > 0)
        {
            int minimumYear = 0;
            int maximumYear = 0;
            
            for(int i = 1; i < numEmployees; i++)
            {
                if(employees[i].getHireDate().getYear() < employees[minimumYear].getHireDate().getYear())
                    minimumYear = i;
                if(employees[i].getHireDate().getYear() > employees[maximumYear].getHireDate().getYear())
                    maximumYear = i;
            }
            
            System.out.println("Earliest Year of Hire: " + employees[minimumYear].getHireDate().getYear());
            System.out.println("Latest Year of Hire: " + employees[maximumYear].getHireDate().getYear());
        }
        else
        {
            System.out.println("There are no employees.");
        }
    }
}